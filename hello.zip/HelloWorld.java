/* *****************************************************************************
 *  Name:              Ionut Draghici
 *  Created:           13 February 2024
 **************************************************************************** */

public class HelloWorld {
    public static void main(String[] args) {
        System.out.println("Hello, World");
    }
}
